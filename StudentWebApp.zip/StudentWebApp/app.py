from flask import Flask, render_template, request, redirect
import json, os

app = Flask(__name__)

FILE = "students.json"
students = {}


# ---------------- File Handling ----------------
def load_data():
    global students
    if os.path.exists(FILE):
        with open(FILE, "r") as f:
            students = json.load(f)


def save_data():
    with open(FILE, "w") as f:
        json.dump(students, f, indent=4)


# ---------------- Home ----------------
@app.route("/")
def home():
    load_data()
    return render_template("index.html", students=students, edit=None)


# ---------------- Add ----------------
@app.route("/add", methods=["POST"])
def add():
    try:
        roll = request.form["roll"]

        if roll in students:
            raise Exception("Student already exists")

        students[roll] = {
            "name": request.form["name"],
            "email": request.form["email"],
            "gender": request.form["gender"],
            "contact": request.form["contact"],
            "dob": request.form["dob"],
            "address": request.form["address"]
        }

        save_data()

    except Exception as e:
        return f"<h3>{e}</h3><a href='/'>Back</a>"

    return redirect("/")


# ---------------- Delete ----------------
@app.route("/delete/<roll>")
def delete(roll):
    load_data()
    if roll in students:
        del students[roll]
        save_data()
    return redirect("/")


# ---------------- Edit (Load data into form) ----------------
@app.route("/edit/<roll>")
def edit(roll):
    load_data()
    return render_template("index.html",
                           students=students,
                           edit=students.get(roll),
                           edit_roll=roll)


# ---------------- Update ----------------
@app.route("/update/<roll>", methods=["POST"])
def update(roll):
    try:
        if roll not in students:
            raise Exception("Student not found")

        students[roll] = {
            "name": request.form["name"],
            "email": request.form["email"],
            "gender": request.form["gender"],
            "contact": request.form["contact"],
            "dob": request.form["dob"],
            "address": request.form["address"]
        }

        save_data()

    except Exception as e:
        return f"<h3>{e}</h3><a href='/'>Back</a>"

    return redirect("/")


# ---------------- Search ----------------
@app.route("/search", methods=["POST"])
def search():
    load_data()
    key = request.form["key"].lower()

    result = {r: d for r, d in students.items()
              if key in r.lower() or key in d["name"].lower()}

    return render_template("index.html", students=result, edit=None)


# ---------------- Run ----------------
if __name__ == "__main__":
    app.run(debug=True)